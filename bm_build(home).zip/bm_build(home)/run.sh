node app.js&node ./build/index.js
