
There is no progress bar for checking downloads
(you can make it up by checking the size of the ipfs directory periodically)

You cannot cancel a download while it is still in progress but you can delete 
it once it's downloaded or by restarting the app.

Update the website by manually replacing the json folder


